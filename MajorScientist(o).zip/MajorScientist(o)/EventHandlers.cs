﻿using System.Collections.Generic;
using System.Linq;
using EXILED;
using EXILED.Extensions;
using MEC;
using UnityEngine;

namespace MajorScientist
{
	partial class EventHandlers
	{
		public Plugin plugin;
		public EventHandlers(Plugin plugin) => this.plugin = plugin;

		internal static ReferenceHub MajorScientist;
		private static bool isHidden;
		private static bool hasTag;
		private bool isRoundStarted;
		private static int maxHP;
		private int MajorEscape = 0;
		private const float dur = 327;
		private static System.Random rand = new System.Random();

		private static List<CoroutineHandle> coroutines = new List<CoroutineHandle>();

		public void OnWaitingForPlayers()
		{
			Configs.ReloadConfig();
		}

		public void OnRoundStart()
		{
			isRoundStarted = true;
			MajorScientist = null;
			MajorEscape = 0;

			Timing.CallDelayed(1f, () => selectspawnMS());


		}

		public void OnRoundEnd()
		{
			isRoundStarted = false;

			Timing.KillCoroutines(coroutines);
			coroutines.Clear();
		}

		public void OnRoundRestart()
		{
			
			isRoundStarted = false;

			Timing.KillCoroutines(coroutines);
			coroutines.Clear();
		}

		public void OnPlayerDie(ref PlayerDeathEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				KillMajorScientist();
				MajorEscape = -1;

			}
		}

		public void OnCheckRoundEnd(ref CheckRoundEndEvent ev)
		{
			List<Team> pList = Player.GetHubs().Where(x => x.queryProcessor.PlayerId != MajorScientist?.queryProcessor.PlayerId).Select(x => Player.GetTeam(x)).ToList();

			// 수석 과학자가 죽으면 MTF는 승리하지 못한다.
			if ((!pList.Contains(Team.CDP) && !pList.Contains(Team.CHI) && !pList.Contains(Team.SCP) && !pList.Contains(Team.TUT) && (MajorEscape == -1) && (pList.Contains(Team.MTF))))
			{
				ev.LeadingTeam = RoundSummary.LeadingTeam.Draw;
				ev.ForceEnd = true;
			}

			// 수석 과학자가 살아 있다면 게임이 계속된다.
			else if (MajorScientist != null)
			{
				if (pList.Contains(Team.RSC))
					ev.Allow = false;
			}
		}

		public void OnCheckEscape(ref CheckEscapeEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				MajorScientist.SetRank("", "default");
				if (hasTag) MajorScientist.RefreshTag();
				if (isHidden) MajorScientist.HideTag();
				MajorScientist = null;
				MajorEscape = 1;

				if (Configs.log)
					Log.Info("Major Scientist has escaped.");
			}
		}

		public void OnSetClass(SetClassEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				KillMajorScientist(false);
				MajorEscape = -1;
			}
		}

		public void OnPlayerLeave(PlayerLeaveEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				KillMajorScientist();
				MajorEscape = -1;
			}

		}

		public void OnContain106(Scp106ContainEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				ev.Allow = true;
				KillMajorScientist();
				MajorEscape = -1;

			}
		}

		public void OnPocketDimensionDie(PocketDimDeathEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				ev.Allow = true;
				KillMajorScientist();
				MajorEscape = -1;
			}
		}

		public void OnUseMedicalItem(MedicalItemEvent ev)
		{
			if (ev.Player.queryProcessor.PlayerId == MajorScientist?.queryProcessor.PlayerId)
			{
				MajorScientist.playerStats.maxHP = Configs.health;
			}
		}
	}
}
